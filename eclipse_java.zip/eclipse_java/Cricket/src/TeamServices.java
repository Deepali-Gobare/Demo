
public class TeamServices {
	static Team[] t;
	static int count;
	static {
		t=new Team[10];
		Player[] p=new Player[15];

	}
	public static void AddNewTeam() {
		
		
	}

}
