public class TestBook {

	public static void main(String[] args) {
		Book b=new Book();
		Book.Lesson l=b.new Lesson();

	}

}
